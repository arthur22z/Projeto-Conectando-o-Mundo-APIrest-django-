from pyexpat.errors import messages
from django.shortcuts import render
import requests
from rest_framework import viewsets

def buscar_pais(request):
    nome = request.GET.get('nome', 'usa').lower()
    dados = None
    erro = None

    if nome:
        url = f'https://restcountries.com/v3.1/name/{nome}?FullText=true'
        resposta = requests.get(url)

        if resposta.status_code == 200:
            dados = resposta.json()[0]
        else:
            erro = "País não encontrado."
    
    pais = {
        "nome_oficial": dados["name"]["official"] if dados else "",
        "idioma": dados.get("languages", {}).get("eng", "Inglês") if dados else "Desconhecido",
        "populacao": dados.get("population", 0) if dados else 0,
        "capital": dados.get("capital", ["Desconhecida"])[0] if dados else "Desconhecida",
        "moeda": ", ".join([f"{sigla} - {info['name']}" for sigla, info in dados.get("currencies", {}).items()]) if dados else "",
        "bandeira_url": dados.get("flags", {}).get("png", "") if dados else "",
    }

    return render(request, 'pais/detalhe_pais.html', {
        'pais': pais,
        'erro': erro,
    })

def extra(request):
    return render(request, 'pais/extra.html')
