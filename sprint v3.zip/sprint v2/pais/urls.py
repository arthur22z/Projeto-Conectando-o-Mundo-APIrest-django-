from django.urls import path
from .views import buscar_pais, extra

urlpatterns = [
    path('detalhe/', buscar_pais, name='buscar_pais'),
    path('extra/', extra, name='extra'),
]