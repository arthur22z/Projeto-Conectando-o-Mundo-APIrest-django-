import subprocess
import sys
from django.shortcuts import redirect, render
from usuarios.models import CadastroUsuarios
from .forms import CadastroUsuariosForm
from rest_framework import viewsets
from .serializers import UsuarioSerializer
from django.shortcuts import render
from django.contrib import messages
import requests

def cadastro_usuarios(request):
    if request.method == 'POST':
        form = CadastroUsuariosForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('usuarios/listar_usuarios.html')
    else:
        form = CadastroUsuariosForm()
    return render(request, 'usuarios/cadastro_usuario.html', {'form': form}) 

def listar_usuarios(request):
    usuarios = CadastroUsuarios.objects.all()
    return render(request, 'usuarios/listar_usuarios.html', {'usuarios': usuarios})

class UsuarioViewSet(viewsets.ModelViewSet):
    queryset = CadastroUsuarios.objects.all()
    serializer_class = UsuarioSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        # Exemplo de filtro por email (pode trocar para outro campo do seu modelo)
        email = self.request.query_params.get('email')
        if email:
            queryset = queryset.filter(email__icontains=email)
        return queryset


def usuarios_parceiro(request):
    api_url = "http://10.90.238.13:8000/usuarios/usuario"
    usuarios = []

    try:
        response = requests.get(api_url, timeout=5)
        response.raise_for_status()
        usuarios = response.json()  
    except Exception as e:
        messages.error(request, f"Erro ao consultar API do parceiro: {e}")

    context = {
        'usuarios': usuarios
    }
    return render(request, 'usuarios/usuarios_parceiro.html', context)


def rodar_testes_usuarios(request):
    log = ""
    if request.method == 'POST':
        try:
            result = subprocess.run(
            [sys.executable, 'manage.py', 'test', 'usuarios', '--verbosity', '2'],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding='utf-8', # Força codificação UTF-8
            errors='replace', # Substitui caracteres inválidos
            check=True
            )
            log = result.stdout

        except subprocess.CalledProcessError as e:
            log = f"ERRO:\n{e.output}"

        except Exception as e:
            log = f"Erro inesperado: {str(e)}"
            
    return render(request, 'usuarios/testes.html', {'log': log})