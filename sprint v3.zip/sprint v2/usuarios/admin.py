from django.contrib import admin
from .models import CadastroUsuarios

# Register your models here.
admin.site.register(CadastroUsuarios)