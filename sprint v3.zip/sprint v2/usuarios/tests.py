from django.test import TestCase
from django.urls import reverse
from usuarios.forms import CadastroUsuariosForm
from .models import CadastroUsuarios
from django.db.utils import IntegrityError

class CadastroUsuariosModelTest(TestCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        print("\n=== TESTE: Modelo CadastroUsuario ===")

    def setUp(self):
        self.CadastroUsuarios = CadastroUsuarios.objects.create(
            nome="teste",
            email= "teste@gmail.com",
            telefone = "1798434765",
            cep = 4932935,
            rua = "ABC",
            estado = "SÃO PAULO",
        )

    def test_usuario_criado(self):
        usuario = CadastroUsuarios.objects.get(nome="teste")
        self.assertEqual(
            usuario.email, "teste@gmail.com",
            "ERRO: O email do usuário não está correto"
        )

        self.assertEqual(
            usuario.telefone, "1798434765",
            "ERRO: O telefone do usuário não está correto"
            )
        
        self.assertEqual(
            usuario.cep, 4932935,
            "ERRO: O CEP do usuário não está correto"
        )

        self.assertEqual(
            usuario.rua, "ABC",
            "ERRO: A rua do usuário não está correto"
        )

        self.assertEqual(
            usuario.estado, "SÃO PAULO",
            "ERRO: O estado do usuário não está correto"
        )


class CadastroUsuariosViewTest(TestCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        print("\n=== TESTE: Views de Cadastro e Listagem dos Usuarios ===")

    def test_cadastrar_usuario(self):
        response = self.client.post(reverse('cadastro_usuarios'), {
            'nome': "teste2",
            'email': "teste2@gmail.com",
            'telefone': "1798434766",
            'cep': 4932936,
            'rua': "DEF",
            'estado': "SÃO PAULO",
        })

        self.assertEqual(response.status_code, 200)
        self.assertTrue(CadastroUsuarios.objects.filter(nome='teste2').exists())

    def test_listar_usuarios(self):
        CadastroUsuarios.objects.create(
            nome="teste3",
            email= "teste3@gmail.com",
            telefone = "1798434767",
            cep = 4932937,
            rua = "GHI",
            estado = "SÃO PAULO",
        )

        response = self.client.get(reverse('listar_usuarios'))
        self.assertEqual(response.status_code, 200)
        content = response.content.decode('utf-8')
        self.assertIn('teste3', content)


class CadastroUsuarioFormTest(TestCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        print("\n=== TESTE: Formularios dos Usuarios ===")

    def test_form_valido(self):
        form = CadastroUsuariosForm(data={
            'nome' : "teste4",
            'email' : "teste4@gmail.com",
            'telefone' : "1798434767",
            'cep' : 4932938,
            'rua' : "JKL",
            'estado' : "SÃO PAULO",
        })
        self.assertTrue(form.is_valid())

    def test_form_invalido(self):
        form = CadastroUsuariosForm(data={
            'nome' : "",
            'email' : "",
            'telefone' : "1798434767",
            'cep' : "",
            'rua' : "",
            'estado' : "",
        })
        
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors['nome'], ['This field is required.']) 
        self.assertEqual(form.errors['email'], ['This field is required.'])
