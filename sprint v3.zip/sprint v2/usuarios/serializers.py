from rest_framework import serializers
from .models import CadastroUsuarios

class UsuarioSerializer(serializers.ModelSerializer):
    class Meta:
        model = CadastroUsuarios
        fields = '__all__'