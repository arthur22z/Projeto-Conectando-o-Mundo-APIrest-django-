from django.urls import path
from .views import cadastro_usuarios, listar_usuarios, rodar_testes_usuarios, usuarios_parceiro
from rest_framework.routers import DefaultRouter
from .views import UsuarioViewSet

router = DefaultRouter()
router.register(r'usuarios', UsuarioViewSet)

urlpatterns = [
    path('lista_usuarios/', listar_usuarios, name='listar_usuarios'),
    path('cadastro/', cadastro_usuarios, name='cadastro_usuarios'),
    path('testes/', rodar_testes_usuarios, name='rodar_testes_usuarios'),
    path('usuarios-parceiro/', usuarios_parceiro, name='usuarios_parceiro'),
]
urlpatterns += router.urls 