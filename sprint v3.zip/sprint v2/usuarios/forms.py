from django import forms
from .models import CadastroUsuarios

class CadastroUsuariosForm(forms.ModelForm):
    class Meta:
        model = CadastroUsuarios
        fields = ['nome', 'email', 'telefone', 'cep', 'rua', 'estado'] 
        widgets = {
            'nome': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'telefone': forms.TextInput(attrs={'class': 'form-control'}),
            'cep': forms.NumberInput(attrs={'class': 'form-control'}),
            'rua': forms.TextInput(attrs={'class': 'form-control'}),
            'estado': forms.TextInput(attrs={'class': 'form-control'}),
        }